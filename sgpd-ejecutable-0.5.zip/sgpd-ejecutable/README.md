# lobo01
pago diario


------------------------------------------------------
- README.md SGPD - Sistema de Gestión de Pago Diario -
------------------------------------------------------

Manual de Usuario:
-----------------

URL: http://localhost:8080/pagodiario/controller/html/login


java -DENV_DIR=. -jar pagodiario.jar


set JAVA_OPTS=%JAVA_OPTS% -DMyLocation=d:\somewhere\some.properties

user: sgpd_admin
password: sgpdadmin


